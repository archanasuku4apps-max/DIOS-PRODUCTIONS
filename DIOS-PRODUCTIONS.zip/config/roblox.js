module.exports = {
  PLACE_ID: "9100306231",

  CHANNEL_ID: "1519014695707607260",

  MESSAGE_ID: "1528736634470793217",

  OWNER: "4adi_ii",

  STAFFS: [
    "lunaz",
    "thefluffy",
    "thevenixDios",
    "VEGETA",
    "toji",
    "anay"
  ],

  GAME_URL: "https://www.roblox.com/games/9100306231"
};
