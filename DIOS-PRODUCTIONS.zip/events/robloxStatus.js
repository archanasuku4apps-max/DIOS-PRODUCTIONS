const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

const config = require("../config/roblox");

async function updateRobloxStatus(client) {
  try {
    const channel = await client.channels.fetch(config.CHANNEL_ID);
    const message = await channel.messages.fetch(config.MESSAGE_ID);

    const embed = new EmbedBuilder()
      .setColor(0x00b0f4)
      .setTitle("🎮 DIOS ROBLOX STATUS")
      .setDescription(
        "🟢 **Game Status:** Online\n\n⏳ Loading live Roblox information..."
      )
      .addFields(
        {
          name: "👑 Owner",
          value: config.OWNER,
          inline: true,
        },
        {
          name: "🛡 Staff Team",
          value: config.STAFFS.join("\n"),
          inline: true,
        }
      )
      .setFooter({
        text: "DIOS PRODUCTIONS",
      })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("🎮 Quick Join")
        .setStyle(ButtonStyle.Link)
        .setURL(config.GAME_URL),

      new ButtonBuilder()
        .setLabel("👤 Owner Profile")
        .setStyle(ButtonStyle.Link)
        .setURL(`https://www.roblox.com/users/profile?username=${config.OWNER}`),

      new ButtonBuilder()
        .setLabel("🌐 Game Page")
        .setStyle(ButtonStyle.Link)
        .setURL(config.GAME_URL)
    );

    await message.edit({
      embeds: [embed],
      components: [row],
    });

    console.log("✅ Roblox status updated.");
  } catch (err) {
    console.error("Roblox Status Error:", err);
  }
}

module.exports = { updateRobloxStatus };
