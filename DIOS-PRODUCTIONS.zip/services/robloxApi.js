const axios = require("axios");

async function getGameData(placeId) {
  try {
    const universe = await axios.get(
      `https://apis.roblox.com/universes/v1/places/${placeId}/universe`
    );

    const universeId = universe.data.universeId;

    const game = await axios.get(
      `https://games.roblox.com/v1/games?universeIds=${universeId}`
    );

    const data = game.data.data[0];

    const thumb = await axios.get(
      `https://thumbnails.roblox.com/v1/games/icons?universeIds=${universeId}&size=512x512&format=Png&isCircular=false`
    );

    return {
      name: data.name,
      playing: data.playing,
      maxPlayers: data.maxPlayers,
      visits: data.visits,
      favorites: data.favoritedCount,
      thumbnail: thumb.data.data[0].imageUrl,
    };
  } catch (err) {
    console.log(err.message);
    return null;
  }
}

module.exports = { getGameData };
